import React from "react";

export default function HomeFren(props) {
  return (
    <div>
      {" "}
      <header>
        <button className={`btn ${props.langButt}`} type="submit">
          Anglais
        </button>
      </header>
      <h1>Bienvenue a la page d'acceuil</h1>
    </div>
  );
}
