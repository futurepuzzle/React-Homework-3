import React from "react";

export default function About() {
  return (
    <div>
      <h1>Information</h1>
    </div>
  );
}
