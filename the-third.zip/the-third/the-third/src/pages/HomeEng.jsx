import React from "react";

export default function HomeEng(props) {
  return (
    <div>
      <header>
        <button>French</button>
      </header>
      <h1>Welcome to the homepage</h1>
    </div>
  );
}
