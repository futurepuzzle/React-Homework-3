import React from "react";
import { Link } from "react-router-dom";
import { useState } from "react";
//home master component, if the user is on the home page, it will display the home page. If the user clicks the language button it will display the home page in the language selected.
export default function Home(props) {
  const [language, setLanguage] = useState({
    french: <Link to="the-third/src/pages/HomeFren.jsx">Home</Link>,
    english: <Link to="the-third/src/pages/HomeEng.jsx">Home</Link>,
  });

  const handleLanguage = (e) => {
    setLanguage({
      ...language,
      [e.target.value]: <Link to={`/pages/${e.target.value}`}>Home</Link>,
    });
  };

  return (
    <div>
      <button onClick={handleLanguage}>{props.english}</button>
      <button onClick={handleLanguage}>{props.french}</button>
    </div>
  );
}
