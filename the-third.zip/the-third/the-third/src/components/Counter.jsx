import React from "react";

export default function Counter() {
  return (
    <div>
      <h1>Counter</h1>
      <button>+</button>
    </div>
  );
}
//the difference between a framework and a library is that a framework is a complete solution that provides everything you need to build a complete application, while a library is a collection of tools that you can use to build a specific part of your application.
