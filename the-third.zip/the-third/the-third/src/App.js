import logo from "./logo.svg";
import "./App.css";
import Home from "./pages/Home";
import About from "./pages/About";
import Contact from "./pages/Contact";
//"as" is an alias
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";

function App() {
  return (
    <div className="App">
      {/* the router is the container for the routes */}
      <Router>
        {/* simulating the navigation bar */}
        <nav>
          <ul>
            <li>
              {/* the link is the link to the page, it differs from the anchor tag by not refreshing the page. Path is the URL defined in the routes */}
              <Link to="/">Home</Link>
            </li>
            <li>
              <Link to="/about">About</Link>
            </li>
            <li>
              <Link to="/contact">Contact</Link>
            </li>
          </ul>
        </nav>
        {/* the routes */}
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/about" element={<About />} />
          <Route path="/contact" element={<Contact />} />{" "}
          {/* the path is the URL */}
        </Routes>
      </Router>
    </div>
  );
}

export default App;
